﻿using Microsoft.AspNetCore.Identity;

namespace IMS.Web.DataAccess.Entities.Account
{
    public class ApplicationUser : IdentityUser
    {

    }
}
